package com.ATMProject;

public interface ATMOperationInterface {

	public void viewBalance();
	public void withdrawAmount(double withdrawAmount);
	public void depositAmount(double depositAmount);
	public void viewMiniStatement();
	
}
